##
#  add eqpy.py as a module
# 
